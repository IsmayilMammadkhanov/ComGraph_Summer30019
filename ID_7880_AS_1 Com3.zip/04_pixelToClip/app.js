onload = () => {
    let canvas = document.getElementById('webgl-canvas');
    let changeColorButton = document.getElementById('change-color-btn');

    // Set up WebGL
    let gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) { 
        alert("Couldn't set up WebGL"); 
        return; 
    }

    // Initialize shaders
    let program = initShaders(gl, 'vertex-shader', 'fragment-shader');
    gl.useProgram(program);

    // Define the vertices of the triangle in pixel coordinates
    let pixelVertices = [
        0, 100,
        50, 0,
        100, 100,
    ];

    /*

                        // Or like this
                    let vertices = pixelToClip2D([
                    0, 100,
                    50, 0,
                    100, 100,
                ]);
     */

    // Convert the vertices to clip coordinates
    let vertices = pixelToClip2D(pixelVertices);

    // Create and bind a buffer for the vertices
    let vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

    // Get the attribute location for the vertex position and enable it
    let vPosition = gl.getAttribLocation(program, 'vPosition');
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    // Set the viewport to cover the entire canvas
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);

    // Get the uniform location for the color
    let uColor = gl.getUniformLocation(program, 'uColor');

    // Function to generate a random color
    function generateRandomColor() {
        return [Math.random(), Math.random(), Math.random(), 1.0];
    }

    // Function to convert pixel coordinates to clip coordinates
    function pixelToClip2D(vertices) {
        let clipVertices = [];
        const canvasWidth = gl.canvas.width;
        const canvasHeight = gl.canvas.height;

        for (let i = 0; i < vertices.length; i += 2) {
            let x = (vertices[i] / canvasWidth) * 2 - 1;
            let y = ((canvasHeight - vertices[i + 1]) / canvasHeight) * 2 - 1;
            clipVertices.push(x, y);
        }

        return clipVertices;
    }

    // Set the initial color of the triangle
    let initialColor = generateRandomColor();
    gl.uniform4fv(uColor, initialColor);

    // Clear the canvas with the initial color
    gl.clearColor(0.6, 0.6, 0.6, 1); //Grey
    gl.clear(gl.COLOR_BUFFER_BIT);

    // Draw the triangle
    gl.drawArrays(gl.TRIANGLES, 0, 3);

    // Function to update the color of the triangle
    function updateTriangleColor() {
        let color = generateRandomColor();
        gl.uniform4fv(uColor, color);
        gl.clear(gl.COLOR_BUFFER_BIT);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
    }

    // Add event listener to the button
    changeColorButton.addEventListener('click', updateTriangleColor);
}
