onload = () => {
    // Get references to the necessary elements
    let canvas = document.getElementById('webgl-canvas');
    let modeSwitchButton = document.getElementById('mode-switch-btn');
    let currentModeLabel = document.getElementById('current-mode');

    // Set up WebGL context
    let gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) { 
        alert("Couldn't set up WebGL"); 
        return; 
    }

    // Initialize shader program
    let program = initShaders(gl, 'vertex-shader', 'fragment-shader');
    gl.useProgram(program);

    // Define vertex data for the square
    let vertices = [
        -0.7, -0.7,
        -0.7, 0.7,
        0.7, -0.7,
        0.7, 0.7
    ];

    // Create and configure vertex buffer
    let vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

    // Get the location of the attribute variable in the shader program
    let vPosition = gl.getAttribLocation(program, 'vPosition');
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    // Set up the viewport
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);

    // Set the clear color and clear the canvas
    gl.clearColor(0, 0, 0, 0.6);
    gl.clear(gl.COLOR_BUFFER_BIT);

    // Initialize render mode
    let renderMode = 'TRIANGLE_STRIP';

    // Function to switch render mode and update label
    function switchRenderMode() {
        if (renderMode === 'TRIANGLE_STRIP') {
            renderMode = 'TRIANGLE_FAN';
        } else {
            renderMode = 'TRIANGLE_STRIP';
        }

        // Update the label with the current render mode
        currentModeLabel.textContent = `Current Render Mode is ${renderMode}`;

        // Render the scene
        render();
    }

    // Function to render the scene
    function render() {
        // Clear the canvas
        gl.clear(gl.COLOR_BUFFER_BIT);

        // Draw the square based on the current render mode
        if (renderMode === 'TRIANGLE_STRIP') {
            gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        } else if (renderMode === 'TRIANGLE_FAN') {
            gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
        }
    }

    // Add event listener to the button
    modeSwitchButton.addEventListener('click', switchRenderMode);

    // Initial render of the scene
    render();
}
