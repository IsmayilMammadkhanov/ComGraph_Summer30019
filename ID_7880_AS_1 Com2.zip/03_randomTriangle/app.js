onload = () => {
    let canvas = document.getElementById('webgl-canvas');
    let changeColorButton = document.getElementById('change-color-btn');

    let gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) { 
        alert("Couldn't set up WebGL"); 
        return; 
    }

    let program = initShaders(gl, 'vertex-shader', 'fragment-shader');
    gl.useProgram(program);

    // Define the vertices of the triangle
    let vertices = [
        -0.7, -0.7,
        0, 0.7,
        0.7, -0.7
    ];

    // Create and bind a buffer for the vertices
    let vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

    // Get the attribute location for the vertex position and enable it
    let vPosition = gl.getAttribLocation(program, 'vPosition');
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    // Set the viewport to cover the entire canvas
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);

    // Get the uniform location for the color
    let uColor = gl.getUniformLocation(program, 'uColor');

    // Function to generate a random color
    function generateRandomColor() {
        return [Math.random(), Math.random(), Math.random(), 1.0];
    }

    // Function to update the color of the triangle
    function updateTriangleColor() {
        let color = generateRandomColor();
        gl.uniform4fv(uColor, color);
        gl.clear(gl.COLOR_BUFFER_BIT);
        gl.drawArrays(gl.TRIANGLES, 0, 3);
    }

    // Set the initial color for the triangle
    let initialColor = generateRandomColor();
    gl.uniform4fv(uColor, initialColor);

    // Add event listener to the button
    changeColorButton.addEventListener('click', updateTriangleColor);

    // Clear the canvas with the initial color
    gl.clearColor(0, 0, 0, 0.6);
    gl.clear(gl.COLOR_BUFFER_BIT);

    // Draw the triangle
    gl.drawArrays(gl.TRIANGLES, 0, 3);
}
