onload = () => {
    // Get the canvas element
    let canvas = document.getElementById('webgl-canvas');
    
    // Set up WebGL
    let gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) { 
      alert("Couldn't set up WebGL"); 
      return; 
    }
    
    // Initialize shaders and set program
    let program = initShaders(gl, 'vertex-shader', 'fragment-shader');
    gl.useProgram(program);
    
    // Create a buffer for vertex data
    let vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    
    // Initialize variables to store vertex coordinates, colors, and triangle count
    let vertices = [];
    let colors = [];
    let triangleCount = 0;
    
    // Get the attribute location for vertex position
    let vPosition = gl.getAttribLocation(program, 'vPosition');
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);
    
    // Set up viewport and clear color
    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);
    gl.clearColor(0.6, 0.6, 0.6, 1); //Grey
    gl.clear(gl.COLOR_BUFFER_BIT);
    
    // Generate a random color for each triangle
    function getRandomColor() {
      return [Math.random(), Math.random(), Math.random(), 1.0];
    }
    
    // Convert pixel coordinates to clip coordinates
    function pixelToClip2D(vertices) {
      let clipVertices = [];
      const canvasWidth = gl.canvas.width;
      const canvasHeight = gl.canvas.height;
    
      for (let i = 0; i < vertices.length; i += 2) {
        let x = (vertices[i] / canvasWidth) * 2 - 1;
        let y = 1 - (vertices[i + 1] / canvasHeight) * 2;
        clipVertices.push(x, y);
      }
    
      return clipVertices;
    }
    
    // Render the triangles
    function renderTriangles() {
      gl.clear(gl.COLOR_BUFFER_BIT);
    
      for (let i = 0; i < triangleCount; i++) {
        let start = i * 3;
        gl.uniform4fv(uColor, colors[i]);
        gl.drawArrays(gl.TRIANGLES, start, 3);
      }
    }
    
    // Event listener for mouse clicks
    canvas.addEventListener('click', (event) => {
      let rect = canvas.getBoundingClientRect();
      let x = event.clientX - rect.left;
      let y = event.clientY - rect.top;
    
      // Add the clicked vertex and its color to the respective arrays
      vertices.push(x, y);
      colors.push(getRandomColor());
    
      // Update the vertex buffer with the converted clip coordinates
      gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(pixelToClip2D(vertices)), gl.STATIC_DRAW);
    
      // If a complete triangle has been formed, increase the triangle count and render
      if (vertices.length % 6 === 0) {
        triangleCount++;
        renderTriangles();
      }
    });
    
    // Get the uniform location for color
    let uColor = gl.getUniformLocation(program, 'uColor');
  }
  