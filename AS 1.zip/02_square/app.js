onload = () => {
    let canvas = document.getElementById('webgl-canvas');
    let modeSwitchButton = document.getElementById('mode-switch-btn');
    let currentModeLabel = document.getElementById('current-mode');

    let gl = WebGLUtils.setupWebGL(canvas);
    if (!gl) { 
        alert("Couldn't set up WebGL"); 
        return; 
    }

    let program = initShaders(gl, 'vertex-shader', 'fragment-shader');
    gl.useProgram(program);

    let vertices = [
        -0.5, -0.5,
        -0.5, 0.5,
        0.5, -0.5,
        0.5, 0.5
    ];

    let vertexBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vertexBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertices), gl.STATIC_DRAW);

    let vPosition = gl.getAttribLocation(program, 'vPosition');
    gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);

    gl.clearColor(0, 0, 0, 1);
    gl.clear(gl.COLOR_BUFFER_BIT);

    let renderMode = 'TRIANGLE_STRIP';

    function switchRenderMode() {
        if (renderMode === 'TRIANGLE_STRIP') {
            renderMode = 'TRIANGLE_FAN';
        } else {
            renderMode = 'TRIANGLE_STRIP';
        }

        currentModeLabel.textContent = `Current Render Mode: ${renderMode}`;

        render();
    }

    function render() {
        gl.clear(gl.COLOR_BUFFER_BIT);

        if (renderMode === 'TRIANGLE_STRIP') {
            gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        } else if (renderMode === 'TRIANGLE_FAN') {
            gl.drawArrays(gl.TRIANGLE_FAN, 0, 4);
        }
    }

    modeSwitchButton.addEventListener('click', switchRenderMode);

    render();
}
