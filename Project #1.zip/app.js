var canvas;
var gl;
var program;

var sphereBuffers = [];
var sphereModels = [];
var sphereColors = [
vec4(1.0, 0.5, 0.0, 1.0), // Orange nucleus (sun)
vec4(0.0, 0.0, 1.0, 1.0), // Blue electron (planet)
vec4(0.0, 1.0, 0.0, 1.0), // Green electron (planet)
vec4(0.6, 0.4, 0.2, 0.6), // Brown electron (planet)
];

var cameraPosition = vec3(0.0, 0.0, 2.0);
var cameraRotation = vec3(0.0, 0.0, 0.0);
var cameraZoom = 0.7;
var cameraRotationSpeed = 5.0;
var cameraMoveSpeed = 0.06;
var cameraZoomSpeed = 0.03;

var lightPosition = vec4(0.0, 0.0, 0.0, 1.0);
var lightAmbient = vec4(0.2, 0.2, 0.2, 1.0);
var lightDiffuse = vec4(1.0, 1.0, 1.0, 1.0);
var lightSpecular = vec4(1.0, 1.0, 1.0, 1.0);

var mvMatrix, pMatrix, nMatrix;
var mvMatrixLoc, pMatrixLoc, nMatrixLoc;
var lightPositionLoc, lightAmbientLoc, lightDiffuseLoc, lightSpecularLoc;





var sphereModels = []; // Array to store sphere models
var orbits = [
  { radius: 0.5, speed: 0.01}, // Blue electron (planet)
  { radius: 0.9, speed: 0.02 }, // Green electron (planet)
  { radius: 1.4, speed: 0.03 }, // Brown electron (planet)
];

function init() {
  canvas = document.getElementById("gl-canvas");
  gl = WebGLUtils.setupWebGL(canvas);
  if (!gl) {
    alert("WebGL isn't available");
  }

  gl.viewport(0, 0, canvas.width, canvas.height);
  gl.clearColor(0.0, 0.0, 0.0, 0.3);

  program = initShaders(gl, "vertex-shader", "fragment-shader");
  gl.useProgram(program);

  createSpheres();

  mvMatrixLoc = gl.getUniformLocation(program, "modelViewMatrix");
  pMatrixLoc = gl.getUniformLocation(program, "projectionMatrix");
  nMatrixLoc = gl.getUniformLocation(program, "normalMatrix");

  lightPositionLoc = gl.getUniformLocation(program, "lightPosition");
  lightAmbientLoc = gl.getUniformLocation(program, "lightAmbient");
  lightDiffuseLoc = gl.getUniformLocation(program, "lightDiffuse");
  lightSpecularLoc = gl.getUniformLocation(program, "lightSpecular");

  window.addEventListener("keydown", handleKeyDown);


  render();
}

function createSpheres() {
  // Create sun (nucleus)
  var sun = {
    buffers: {},
    modelMatrix: mat4(),
    color: sphereColors[0], // Orange color for the nucleus
    radius: 0.3, // Set the radius for the sun (nucleus)
  };
  sun.buffers = initSphereBuffers(sun.color, sun.radius);
  sphereModels.push(sun);

  // Create electrons (planets)
  var planetRadii = [0.09, 0.19, 0.12]; // Radius of each planet
  for (var i = 1; i <= orbits.length; i++) {
    var sphere = {
      buffers: {},
      modelMatrix: mat4(),
      color: sphereColors[i], // Colors for the electrons
      radius: planetRadii[i - 1], // Assign radius based on index
    };
    sphere.buffers = initSphereBuffers(sphere.color, sphere.radius);
    sphereModels.push(sphere);
  }
}


function initSphereBuffers(color, radius) {
  var latitudeBands = 30;
  var longitudeBands = 30;

  var vertexPositionData = [];
  var normalData = [];
  var indexData = [];

  for (var latNumber = 0; latNumber <= latitudeBands; latNumber++) {
    var theta = (latNumber * Math.PI) / latitudeBands;
    var sinTheta = Math.sin(theta);
    var cosTheta = Math.cos(theta);

    for (var longNumber = 0; longNumber <= longitudeBands; longNumber++) {
      var phi = (longNumber * 2 * Math.PI) / longitudeBands;
      var sinPhi = Math.sin(phi);
      var cosPhi = Math.cos(phi);

      var x = cosPhi * sinTheta;
      var y = cosTheta;
      var z = sinPhi * sinTheta;
      var u = 1 - (longNumber / longitudeBands);
      var v = 1 - (latNumber / latitudeBands);

      normalData.push(x);
      normalData.push(y);
      normalData.push(z);
      vertexPositionData.push(radius * x);
      vertexPositionData.push(radius * y);
      vertexPositionData.push(radius * z);
    }
  }

  for (var latNumber = 0; latNumber < latitudeBands; latNumber++) {
    for (var longNumber = 0; longNumber < longitudeBands; longNumber++) {
      var first = latNumber * (longitudeBands + 1) + longNumber;
      var second = first + longitudeBands + 1;

      indexData.push(first);
      indexData.push(second);
      indexData.push(first + 1);

      indexData.push(second);
      indexData.push(second + 1);
      indexData.push(first + 1);
    }
  }

  var sphereBuffers = {
    vertexBuffer: gl.createBuffer(),
    normalBuffer: gl.createBuffer(),
    indexBuffer: gl.createBuffer(),
    numIndices: indexData.length,
  };

  gl.bindBuffer(gl.ARRAY_BUFFER, sphereBuffers.vertexBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(vertexPositionData), gl.STATIC_DRAW);

  gl.bindBuffer(gl.ARRAY_BUFFER, sphereBuffers.normalBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(normalData), gl.STATIC_DRAW);

  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, sphereBuffers.indexBuffer);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(indexData), gl.STATIC_DRAW);

  return sphereBuffers;
}




function handleKeyDown(event) {
  var key = event.key.toLowerCase();

  switch (key) {
    case "w":
      cameraZoom += cameraZoomSpeed; // Zoom in
      break;
    case "s":
      cameraZoom -= cameraZoomSpeed; // Zoom out
      break;
    case "a":
      cameraRotation[1] -= cameraRotationSpeed; // Rotate camera clockwise 
      break;
    case "d":
      cameraRotation[1] += cameraRotationSpeed; // Rotate camera counter-clockwise 
      break;
    case "arrowup":
      cameraPosition[1] += cameraMoveSpeed; // Move camera up
      break;
    case "arrowdown":
      cameraPosition[1] -= cameraMoveSpeed; // Move camera down
      break;
    case "arrowleft":
      cameraPosition[0] -= cameraMoveSpeed; // Move camera left
      break;
    case "arrowright":
      cameraPosition[0] += cameraMoveSpeed; // Move camera right
      break;
  }
}

function render() {
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  gl.enable(gl.DEPTH_TEST);

  var aspect = canvas.width / canvas.height;
  pMatrix = perspective(60.0, aspect, 0.1, 100.0);

  // Apply camera transformations
  var viewMatrix = mult(
    translate(-cameraPosition[0], -cameraPosition[1], -cameraPosition[2]),
    rotateY(cameraRotation[1])  // Rotate around the y-axis
  );

  // Apply camera zoom
  viewMatrix = mult(viewMatrix, scalem(cameraZoom, cameraZoom, cameraZoom));

  for (var i = 0; i < sphereModels.length; i++) {
    var sphere = sphereModels[i];

    var orbitRadius, orbitSpeed, rotationSpeed;
    var orbitAngle, rotationAngle;

    if (i === 0) {
      // Render the sun (nucleus)
      sphere.modelMatrix = translate(0.0, 0.0, 0.0); // Position the sun at the center
    } else {
      // Render the electrons (planets)
      var orbitIndex = i - 1; // Adjust index to match the orbits array
      orbitRadius = orbits[orbitIndex].radius;
      orbitSpeed = orbits[orbitIndex].speed;
      rotationSpeed = 0.02;

      orbitAngle = orbitSpeed * Date.now() * 0.001;
      rotationAngle = rotationSpeed * Date.now() * 0.001;

      sphere.modelMatrix = mult(
        translate(orbitRadius * Math.cos(orbitAngle), 0.0, orbitRadius * Math.sin(orbitAngle)),
        rotateY(rotationAngle)
      );
    }

    gl.uniformMatrix4fv(mvMatrixLoc, false, flatten(viewMatrix));
    gl.uniformMatrix4fv(pMatrixLoc, false, flatten(pMatrix));

    mvMatrix = mult(viewMatrix, sphere.modelMatrix);
    nMatrix = normalMatrix(mvMatrix, true);
    gl.uniformMatrix4fv(mvMatrixLoc, false, flatten(mvMatrix));
    gl.uniformMatrix4fv(nMatrixLoc, false, flatten(nMatrix));

    gl.uniform4fv(lightPositionLoc, flatten(lightPosition));
    gl.uniform4fv(lightAmbientLoc, flatten(lightAmbient));
    gl.uniform4fv(lightDiffuseLoc, flatten(lightDiffuse));
    gl.uniform4fv(lightSpecularLoc, flatten(lightSpecular));

    gl.bindBuffer(gl.ARRAY_BUFFER, sphere.buffers.vertexBuffer);
    var vPosition = gl.getAttribLocation(program, "vPosition");
    gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    gl.bindBuffer(gl.ARRAY_BUFFER, sphere.buffers.normalBuffer);
    var vNormal = gl.getAttribLocation(program, "vNormal");
    gl.vertexAttribPointer(vNormal, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vNormal);

    // Set the color uniform in the shader program
    var colorLoc = gl.getUniformLocation(program, "uColor");
    gl.uniform4fv(colorLoc, sphere.color);

    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, sphere.buffers.indexBuffer);
    gl.drawElements(
      gl.TRIANGLES,
      sphere.buffers.numIndices,
      gl.UNSIGNED_SHORT,
      0
    );
  }

  requestAnimationFrame(render);
}




window.onload = init;